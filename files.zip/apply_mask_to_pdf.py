#!/usr/bin/env python3
"""
Script para aplicar una máscara PNG a un PDF manteniendo sus propiedades vectoriales.
La máscara se divide en una cuadrícula y se aplica mediante clips vectoriales rectangulares.
"""

import pymupdf  # PyMuPDF
from PIL import Image
import numpy as np
import argparse
import sys


def load_mask(mask_path):
    """
    Carga la máscara PNG y la convierte a blanco y negro.
    Retorna un array numpy donde True = área visible (blanco).
    """
    img = Image.open(mask_path).convert('L')  # Convertir a escala de grises
    mask_array = np.array(img)
    # Consideramos blanco (> 127) como área visible
    return mask_array > 127, img.size


def create_grid_sections(mask, grid_size):
    """
    Divide la máscara en una cuadrícula de grid_size x grid_size secciones.
    Retorna una lista de rectángulos (x0, y0, x1, y1) en coordenadas normalizadas [0,1].
    """
    height, width = mask.shape
    sections = []
    
    cell_height = height / grid_size
    cell_width = width / grid_size
    
    for row in range(grid_size):
        for col in range(grid_size):
            # Coordenadas de la celda en píxeles
            y0_px = int(row * cell_height)
            y1_px = int((row + 1) * cell_height)
            x0_px = int(col * cell_width)
            x1_px = int((col + 1) * cell_width)
            
            # Extraer la región de la máscara
            region = mask[y0_px:y1_px, x0_px:x1_px]
            
            # Si la región contiene al menos un píxel blanco (visible), incluir esta sección
            if np.any(region):
                # Convertir a coordenadas normalizadas [0, 1]
                x0_norm = x0_px / width
                y0_norm = y0_px / height
                x1_norm = x1_px / width
                y1_norm = y1_px / height
                
                sections.append((x0_norm, y0_norm, x1_norm, y1_norm))
    
    return sections


def apply_mask_to_pdf(pdf_path, mask_path, output_path, grid_size=20):
    """
    Aplica la máscara al PDF mediante clips vectoriales rectangulares.
    
    Args:
        pdf_path: Ruta al archivo PDF de entrada
        mask_path: Ruta a la imagen PNG de la máscara
        output_path: Ruta para guardar el PDF resultante
        grid_size: Número de divisiones por lado (grid_size x grid_size)
    """
    
    print(f"Cargando máscara desde: {mask_path}")
    mask, mask_size = load_mask(mask_path)
    print(f"Tamaño de máscara: {mask_size[0]}x{mask_size[1]} px")
    
    print(f"Dividiendo máscara en cuadrícula de {grid_size}x{grid_size} = {grid_size*grid_size} celdas")
    sections = create_grid_sections(mask, grid_size)
    print(f"Secciones con contenido visible: {len(sections)}")
    
    print(f"Abriendo PDF: {pdf_path}")
    doc = pymupdf.open(pdf_path)
    
    # Procesar cada página
    for page_num in range(len(doc)):
        page = doc[page_num]
        page_rect = page.rect
        
        print(f"\nProcesando página {page_num + 1}/{len(doc)}")
        print(f"  Tamaño de página: {page_rect.width:.2f} x {page_rect.height:.2f} pt")
        
        # Crear una nueva forma (Shape) para aplicar los clips
        # Primero, necesitamos crear un nuevo contenido con los clips aplicados
        
        # Estrategia: insertar rectángulos de clip para cada sección visible
        # PyMuPDF permite establecer el clip_rect antes de redibujar contenido
        
        # Guardamos el contenido original
        original_contents = page.get_contents()
        
        # Creamos un nuevo documento temporal para esta página
        temp_doc = pymupdf.open()
        temp_page = temp_doc.new_page(width=page_rect.width, height=page_rect.height)
        
        # Para cada sección visible, copiamos el contenido con clip
        for section in sections:
            x0_norm, y0_norm, x1_norm, y1_norm = section
            
            # Convertir coordenadas normalizadas a coordenadas de página
            x0 = page_rect.x0 + x0_norm * page_rect.width
            y0 = page_rect.y0 + y0_norm * page_rect.height
            x1 = page_rect.x0 + x1_norm * page_rect.width
            y1 = page_rect.y0 + y1_norm * page_rect.height
            
            clip_rect = pymupdf.Rect(x0, y0, x1, y1)
            
            # Mostrar la página original con este clip
            temp_page.show_pdf_page(
                temp_page.rect,
                doc,
                page_num,
                clip=clip_rect
            )
        
        # Reemplazar la página original con la página procesada
        page.show_pdf_page(page.rect, temp_doc, 0)
        temp_doc.close()
        
        print(f"  Aplicados {len(sections)} clips vectoriales")
    
    print(f"\nGuardando PDF resultante en: {output_path}")
    doc.save(output_path, garbage=4, deflate=True)
    doc.close()
    
    print("✓ Proceso completado exitosamente")


def main():
    parser = argparse.ArgumentParser(
        description='Aplica una máscara PNG a un PDF manteniendo propiedades vectoriales',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Ejemplos de uso:
  %(prog)s input.pdf mask.png output.pdf
  %(prog)s input.pdf mask.png output.pdf --grid-size 30
  %(prog)s input.pdf mask.png output.pdf -g 50

La máscara debe ser una imagen en blanco y negro donde:
  - Blanco (píxeles > 127) = área visible
  - Negro (píxeles ≤ 127) = área a eliminar
        """
    )
    
    parser.add_argument('pdf_path', help='Ruta al archivo PDF de entrada')
    parser.add_argument('mask_path', help='Ruta a la imagen PNG de la máscara')
    parser.add_argument('output_path', help='Ruta para guardar el PDF resultante')
    parser.add_argument(
        '-g', '--grid-size',
        type=int,
        default=20,
        help='Tamaño de la cuadrícula (NxN). Mayor = más preciso pero más pesado (default: 20)'
    )
    
    args = parser.parse_args()
    
    # Validaciones
    if args.grid_size < 1:
        print("Error: grid-size debe ser al menos 1", file=sys.stderr)
        sys.exit(1)
    
    if args.grid_size > 200:
        print("Advertencia: grid-size muy grande puede generar archivos pesados y procesamiento lento")
    
    try:
        apply_mask_to_pdf(
            args.pdf_path,
            args.mask_path,
            args.output_path,
            args.grid_size
        )
    except FileNotFoundError as e:
        print(f"Error: Archivo no encontrado - {e}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"Error durante el procesamiento: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == '__main__':
    main()
