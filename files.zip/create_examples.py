#!/usr/bin/env python3
"""
Script de ejemplo para crear un PDF y una máscara de prueba.
Útil para demostrar el funcionamiento del aplicador de máscaras.
"""

import pymupdf
from PIL import Image, ImageDraw
import numpy as np


def create_sample_pdf(output_path="sample.pdf"):
    """Crea un PDF de ejemplo con contenido vectorial."""
    doc = pymupdf.open()
    page = doc.new_page(width=595, height=842)  # A4
    
    # Añadir texto
    page.insert_text((50, 50), "PDF de Ejemplo con Contenido Vectorial", fontsize=20)
    page.insert_text((50, 100), "Este texto se mantendrá vectorial después de aplicar la máscara", fontsize=12)
    
    # Añadir formas vectoriales
    shape = page.new_shape()
    
    # Círculo rojo
    shape.draw_circle((150, 200), 50)
    shape.finish(color=(1, 0, 0), fill=(1, 0, 0))
    
    # Rectángulo azul
    shape.draw_rect(pymupdf.Rect(300, 150, 450, 250))
    shape.finish(color=(0, 0, 1), fill=(0, 0, 1))
    
    # Líneas verdes
    for i in range(10):
        y = 350 + i * 20
        shape.draw_line((50, y), (545, y))
        shape.finish(color=(0, 0.7, 0), width=2)
    
    # Polígono amarillo
    points = [(100, 600), (200, 550), (250, 650), (150, 700)]
    shape.draw_polyline(points)
    shape.finish(color=(1, 1, 0), fill=(1, 1, 0), closePath=True)
    
    shape.commit()
    
    doc.save(output_path)
    doc.close()
    print(f"✓ PDF de ejemplo creado: {output_path}")


def create_circular_mask(output_path="mask_circular.png", size=(595, 842)):
    """Crea una máscara circular (forma cóncava)."""
    img = Image.new('L', size, 0)  # Negro
    draw = ImageDraw.Draw(img)
    
    # Círculo blanco en el centro
    center_x, center_y = size[0] // 2, size[1] // 2
    radius = min(size) // 3
    draw.ellipse(
        [center_x - radius, center_y - radius, center_x + radius, center_y + radius],
        fill=255
    )
    
    img.save(output_path)
    print(f"✓ Máscara circular creada: {output_path}")


def create_star_mask(output_path="mask_star.png", size=(595, 842)):
    """Crea una máscara en forma de estrella (forma cóncava compleja)."""
    img = Image.new('L', size, 0)  # Negro
    draw = ImageDraw.Draw(img)
    
    # Calcular puntos de una estrella de 5 puntas
    center_x, center_y = size[0] // 2, size[1] // 2
    outer_radius = min(size) // 3
    inner_radius = outer_radius // 2.5
    
    points = []
    import math
    for i in range(10):
        angle = math.pi / 2 + (2 * math.pi * i / 10)
        radius = outer_radius if i % 2 == 0 else inner_radius
        x = center_x + radius * math.cos(angle)
        y = center_y - radius * math.sin(angle)
        points.append((x, y))
    
    draw.polygon(points, fill=255)
    
    img.save(output_path)
    print(f"✓ Máscara de estrella creada: {output_path}")


def create_gradient_mask(output_path="mask_gradient.png", size=(595, 842)):
    """Crea una máscara con degradado diagonal."""
    img = Image.new('L', size, 0)
    pixels = img.load()
    
    for y in range(size[1]):
        for x in range(size[0]):
            # Degradado diagonal
            value = int(255 * (x + y) / (size[0] + size[1]))
            pixels[x, y] = value
    
    img.save(output_path)
    print(f"✓ Máscara con degradado creada: {output_path}")


def create_complex_mask(output_path="mask_complex.png", size=(595, 842)):
    """Crea una máscara compleja con múltiples formas."""
    img = Image.new('L', size, 0)
    draw = ImageDraw.Draw(img)
    
    # Múltiples círculos
    for i in range(3):
        for j in range(4):
            x = 100 + i * 200
            y = 150 + j * 180
            draw.ellipse([x - 60, y - 60, x + 60, y + 60], fill=255)
    
    img.save(output_path)
    print(f"✓ Máscara compleja creada: {output_path}")


if __name__ == '__main__':
    print("Creando archivos de ejemplo...\n")
    
    create_sample_pdf("sample.pdf")
    create_circular_mask("mask_circular.png")
    create_star_mask("mask_star.png")
    create_gradient_mask("mask_gradient.png")
    create_complex_mask("mask_complex.png")
    
    print("\n" + "="*60)
    print("Archivos de ejemplo creados exitosamente!")
    print("="*60)
    print("\nPara aplicar las máscaras, ejecuta:")
    print("\n  python apply_mask_to_pdf.py sample.pdf mask_circular.png output_circular.pdf")
    print("  python apply_mask_to_pdf.py sample.pdf mask_star.png output_star.pdf -g 30")
    print("  python apply_mask_to_pdf.py sample.pdf mask_complex.png output_complex.pdf -g 40")
    print("\nParámetro -g (--grid-size): mayor número = más precisión pero archivo más pesado")
