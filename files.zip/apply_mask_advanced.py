#!/usr/bin/env python3
"""
Versión mejorada del aplicador de máscaras con estadísticas y visualización.
"""

import pymupdf
from PIL import Image
import numpy as np
import argparse
import sys
import time


def print_progress_bar(iteration, total, prefix='', suffix='', length=50, fill='█'):
    """Muestra una barra de progreso en consola."""
    percent = f"{100 * (iteration / float(total)):.1f}"
    filled_length = int(length * iteration // total)
    bar = fill * filled_length + '-' * (length - filled_length)
    print(f'\r{prefix} |{bar}| {percent}% {suffix}', end='', flush=True)
    if iteration == total:
        print()


def load_mask(mask_path):
    """Carga la máscara y retorna array numpy y estadísticas."""
    img = Image.open(mask_path).convert('L')
    mask_array = np.array(img)
    binary_mask = mask_array > 127
    
    stats = {
        'size': img.size,
        'total_pixels': mask_array.size,
        'visible_pixels': np.sum(binary_mask),
        'hidden_pixels': np.sum(~binary_mask),
        'visibility_percent': (np.sum(binary_mask) / mask_array.size) * 100
    }
    
    return binary_mask, img.size, stats


def create_grid_sections(mask, grid_size, verbose=False):
    """
    Divide la máscara en grid con análisis detallado.
    """
    height, width = mask.shape
    sections = []
    section_stats = []
    
    cell_height = height / grid_size
    cell_width = width / grid_size
    
    total_cells = grid_size * grid_size
    
    if verbose:
        print(f"\nAnalizando {total_cells} celdas...")
    
    for row in range(grid_size):
        for col in range(grid_size):
            y0_px = int(row * cell_height)
            y1_px = int((row + 1) * cell_height)
            x0_px = int(col * cell_width)
            x1_px = int((col + 1) * cell_width)
            
            region = mask[y0_px:y1_px, x0_px:x1_px]
            visible_ratio = np.sum(region) / region.size if region.size > 0 else 0
            
            if visible_ratio > 0:  # Si hay al menos un píxel visible
                x0_norm = x0_px / width
                y0_norm = y0_px / height
                x1_norm = x1_px / width
                y1_norm = y1_px / height
                
                sections.append((x0_norm, y0_norm, x1_norm, y1_norm))
                section_stats.append({
                    'row': row,
                    'col': col,
                    'visible_ratio': visible_ratio
                })
            
            if verbose and (row * grid_size + col + 1) % max(1, total_cells // 20) == 0:
                print_progress_bar(
                    row * grid_size + col + 1,
                    total_cells,
                    prefix='Progreso',
                    suffix='Completado'
                )
    
    if verbose:
        print_progress_bar(total_cells, total_cells, prefix='Progreso', suffix='Completado')
    
    return sections, section_stats


def apply_mask_to_pdf(pdf_path, mask_path, output_path, grid_size=20, verbose=True):
    """
    Versión mejorada con estadísticas y progreso visual.
    """
    start_time = time.time()
    
    if verbose:
        print("="*70)
        print("  APLICADOR DE MÁSCARAS PDF - VERSIÓN MEJORADA")
        print("="*70)
    
    # Cargar máscara
    if verbose:
        print(f"\n[1/4] Cargando máscara: {mask_path}")
    
    mask, mask_size, mask_stats = load_mask(mask_path)
    
    if verbose:
        print(f"      Dimensiones: {mask_size[0]} x {mask_size[1]} px")
        print(f"      Píxeles visibles: {mask_stats['visible_pixels']:,} ({mask_stats['visibility_percent']:.1f}%)")
        print(f"      Píxeles ocultos: {mask_stats['hidden_pixels']:,} ({100-mask_stats['visibility_percent']:.1f}%)")
    
    # Crear grid
    if verbose:
        print(f"\n[2/4] Creando cuadrícula {grid_size}x{grid_size}")
    
    sections, section_stats = create_grid_sections(mask, grid_size, verbose)
    
    if verbose:
        print(f"      Total de celdas: {grid_size * grid_size:,}")
        print(f"      Celdas visibles: {len(sections):,} ({len(sections)/(grid_size*grid_size)*100:.1f}%)")
        print(f"      Celdas descartadas: {grid_size*grid_size - len(sections):,}")
    
    # Abrir PDF
    if verbose:
        print(f"\n[3/4] Procesando PDF: {pdf_path}")
    
    doc = pymupdf.open(pdf_path)
    total_pages = len(doc)
    
    if verbose:
        print(f"      Total de páginas: {total_pages}")
    
    # Procesar páginas
    for page_num in range(total_pages):
        page = doc[page_num]
        page_rect = page.rect
        
        if verbose:
            print(f"\n      Página {page_num + 1}/{total_pages}")
            print(f"        Tamaño: {page_rect.width:.1f} x {page_rect.height:.1f} pt")
            print(f"        Aplicando {len(sections)} clips...", end=' ', flush=True)
        
        temp_doc = pymupdf.open()
        temp_page = temp_doc.new_page(width=page_rect.width, height=page_rect.height)
        
        for i, section in enumerate(sections):
            x0_norm, y0_norm, x1_norm, y1_norm = section
            
            x0 = page_rect.x0 + x0_norm * page_rect.width
            y0 = page_rect.y0 + y0_norm * page_rect.height
            x1 = page_rect.x0 + x1_norm * page_rect.width
            y1 = page_rect.y0 + y1_norm * page_rect.height
            
            clip_rect = pymupdf.Rect(x0, y0, x1, y1)
            
            temp_page.show_pdf_page(
                temp_page.rect,
                doc,
                page_num,
                clip=clip_rect
            )
        
        page.show_pdf_page(page.rect, temp_doc, 0)
        temp_doc.close()
        
        if verbose:
            print("✓")
    
    # Guardar
    if verbose:
        print(f"\n[4/4] Guardando resultado: {output_path}")
    
    doc.save(output_path, garbage=4, deflate=True)
    
    # Estadísticas finales
    import os
    input_size = os.path.getsize(pdf_path)
    output_size = os.path.getsize(output_path)
    
    doc.close()
    
    end_time = time.time()
    elapsed = end_time - start_time
    
    if verbose:
        print("\n" + "="*70)
        print("  RESUMEN DEL PROCESO")
        print("="*70)
        print(f"  Grid utilizado:        {grid_size} x {grid_size} = {grid_size*grid_size:,} celdas")
        print(f"  Clips aplicados:       {len(sections):,} rectángulos")
        print(f"  Páginas procesadas:    {total_pages}")
        print(f"  Tamaño original:       {input_size:,} bytes ({input_size/1024:.1f} KB)")
        print(f"  Tamaño resultante:     {output_size:,} bytes ({output_size/1024:.1f} KB)")
        print(f"  Cambio de tamaño:      {output_size/input_size*100:.1f}%")
        print(f"  Tiempo de proceso:     {elapsed:.2f} segundos")
        print("="*70)
        print("  ✓ Proceso completado exitosamente")
        print("="*70 + "\n")


def main():
    parser = argparse.ArgumentParser(
        description='Aplicador de máscaras PDF (Versión mejorada con estadísticas)',
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    
    parser.add_argument('pdf_path', help='PDF de entrada')
    parser.add_argument('mask_path', help='Máscara PNG (blanco=visible, negro=oculto)')
    parser.add_argument('output_path', help='PDF de salida')
    parser.add_argument('-g', '--grid-size', type=int, default=20,
                       help='Tamaño del grid NxN (default: 20)')
    parser.add_argument('-q', '--quiet', action='store_true',
                       help='Modo silencioso (sin mensajes de progreso)')
    
    args = parser.parse_args()
    
    if args.grid_size < 1:
        print("Error: grid-size debe ser al menos 1", file=sys.stderr)
        sys.exit(1)
    
    try:
        apply_mask_to_pdf(
            args.pdf_path,
            args.mask_path,
            args.output_path,
            args.grid_size,
            verbose=not args.quiet
        )
    except FileNotFoundError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == '__main__':
    main()
