# Aplicador de Máscaras PNG a PDF (Vectorial)

Herramienta para aplicar máscaras PNG en blanco y negro a archivos PDF manteniendo sus propiedades vectoriales.

## 🎯 Características

- ✅ Mantiene el contenido vectorial del PDF
- ✅ Soporta máscaras cóncavas y formas complejas
- ✅ División configurable en cuadrícula (grid)
- ✅ Aproximación progresiva de formas irregulares
- ✅ Compatible con múltiples páginas

## 📋 Requisitos

```bash
pip install PyMuPDF Pillow numpy
```

## 🚀 Uso Básico

```bash
python apply_mask_to_pdf.py <PDF_entrada> <PNG_mascara> <PDF_salida> [opciones]
```

### Ejemplos

```bash
# Usar grid por defecto (20x20)
python apply_mask_to_pdf.py documento.pdf mascara.png resultado.pdf

# Mayor precisión con grid 30x30
python apply_mask_to_pdf.py documento.pdf mascara.png resultado.pdf --grid-size 30

# Máxima precisión con grid 50x50 (archivo más pesado)
python apply_mask_to_pdf.py documento.pdf mascara.png resultado.pdf -g 50
```

## 🎨 Formato de la Máscara

La máscara debe ser una imagen PNG en blanco y negro:

- **Blanco (píxeles > 127)**: Área visible (se mantiene)
- **Negro (píxeles ≤ 127)**: Área a eliminar (se oculta)

```
┌─────────────────┐
│ Negro (oculto)  │
│  ┌──────────┐   │
│  │  Blanco  │   │  ← Esta área se mantiene
│  │ (visible)│   │
│  └──────────┘   │
│ Negro (oculto)  │
└─────────────────┘
```

## ⚙️ Parámetro Grid Size

El parámetro `--grid-size` (o `-g`) controla cuántas divisiones se hacen:

| Grid Size | Celdas | Precisión | Tamaño Archivo | Uso Recomendado |
|-----------|--------|-----------|----------------|-----------------|
| 10 | 100 | Baja | Pequeño | Formas simples |
| 20 | 400 | Media | Moderado | **Por defecto** |
| 30 | 900 | Alta | Grande | Formas detalladas |
| 50 | 2,500 | Muy alta | Muy grande | Formas complejas |
| 100 | 10,000 | Extrema | Enorme | Solo si es necesario |

### Cómo Funciona

```
Máscara original (forma cóncava):        Grid 4x4:              Grid 8x8:

        ████████                         ┌─┬─┬─┬─┐              ┌┬┬┬┬┬┬┬┐
      ██        ██                       ├─┼─┼─┼─┤              ├┼┼┼┼┼┼┼┤
    ██            ██                     ├─┼─┼─┼─┤              ├┼┼┼┼┼┼┼┤
    ██            ██                     ├─┼─┼─┼─┤              ├┼┼┼┼┼┼┼┤
    ██            ██                     └─┴─┴─┴─┘              ├┼┼┼┼┼┼┼┤
      ██        ██                                              ├┼┼┼┼┼┼┼┤
        ████████                         Aprox. baja           ├┼┼┼┼┼┼┼┤
                                                               └┴┴┴┴┴┴┴┘
                                                               Aprox. alta
```

## 🧪 Archivos de Prueba

Para generar archivos de ejemplo:

```bash
python create_examples.py
```

Esto creará:
- `sample.pdf` - PDF con contenido vectorial de ejemplo
- `mask_circular.png` - Máscara circular
- `mask_star.png` - Máscara en forma de estrella
- `mask_gradient.png` - Máscara con degradado
- `mask_complex.png` - Máscara con múltiples formas

Luego puedes probar:

```bash
python apply_mask_to_pdf.py sample.pdf mask_star.png output_star.pdf -g 30
```

## 💡 Consejos

1. **Formas simples**: Usa grid-size entre 10-20
2. **Formas complejas**: Usa grid-size entre 30-50
3. **Degradados**: Requieren grid-size alto (50+)
4. **Balance**: Más grid = más preciso pero archivo más pesado

## 🔧 Cómo Funciona Internamente

1. **Carga la máscara**: Convierte PNG a matriz binaria
2. **División en grid**: Divide la máscara en NxN celdas
3. **Análisis de celdas**: Detecta qué celdas contienen contenido visible
4. **Aplicación vectorial**: Crea clips rectangulares para cada celda visible
5. **Reconstrucción**: Aplica los clips al PDF manteniendo vectores

```python
# Ejemplo conceptual
for cada_celda in grid:
    if celda_tiene_contenido_visible:
        aplicar_clip_rectangular_vectorial(celda)
```

## 📊 Comparación: Vectorial vs Rasterizado

| Aspecto | Este Script (Vectorial) | Conversión a Imagen |
|---------|------------------------|---------------------|
| Calidad de texto | ✅ Perfecta | ❌ Pixelado al zoom |
| Tamaño de archivo | ✅ Pequeño-Mediano | ❌ Grande |
| Búsqueda de texto | ✅ Funciona | ❌ No funciona |
| Impresión | ✅ Alta calidad | ⚠️ Depende de DPI |
| Formas exactas | ⚠️ Aproximadas | ✅ Exactas |

## ⚠️ Limitaciones

- Las formas se aproximan mediante rectángulos
- Mayor precisión requiere más celdas (archivo más pesado)
- No soporta transparencia gradual (solo blanco/negro)

## 📝 Opciones Avanzadas

### Ver ayuda completa:
```bash
python apply_mask_to_pdf.py --help
```

### Estructura del comando:
```bash
python apply_mask_to_pdf.py \
    entrada.pdf \           # PDF original
    mascara.png \           # Máscara B&N
    salida.pdf \            # PDF resultante
    --grid-size 30          # Precisión (opcional)
```

## 🐛 Solución de Problemas

**Error: Archivo no encontrado**
```bash
# Verifica las rutas
ls -la entrada.pdf mascara.png
```

**Archivo de salida muy grande**
```bash
# Reduce el grid-size
python apply_mask_to_pdf.py in.pdf mask.png out.pdf -g 15
```

**Máscara no se aplica correctamente**
```bash
# Verifica que la máscara sea B&N
# Blanco = visible, Negro = oculto
python -c "from PIL import Image; Image.open('mask.png').show()"
```

## 📄 Licencia

Código de ejemplo para uso libre.

## 🤝 Contribuciones

Sugerencias y mejoras son bienvenidas.
