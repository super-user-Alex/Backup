#!/usr/bin/env python3
"""
Script de instalación y verificación de dependencias.
"""

import subprocess
import sys


def check_python_version():
    """Verifica la versión de Python."""
    version = sys.version_info
    print(f"Python versión: {version.major}.{version.minor}.{version.micro}")
    
    if version.major < 3 or (version.major == 3 and version.minor < 7):
        print("❌ Se requiere Python 3.7 o superior")
        return False
    
    print("✓ Versión de Python compatible")
    return True


def install_package(package_name):
    """Instala un paquete usando pip."""
    try:
        print(f"\nInstalando {package_name}...", end=' ', flush=True)
        subprocess.check_call(
            [sys.executable, "-m", "pip", "install", package_name, "--quiet"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )
        print("✓")
        return True
    except subprocess.CalledProcessError:
        print("❌")
        return False


def check_import(module_name, package_name=None):
    """Verifica si un módulo puede importarse."""
    if package_name is None:
        package_name = module_name
    
    try:
        __import__(module_name)
        print(f"✓ {package_name} está instalado")
        return True
    except ImportError:
        print(f"❌ {package_name} no está instalado")
        return False


def main():
    print("="*60)
    print("  VERIFICACIÓN E INSTALACIÓN DE DEPENDENCIAS")
    print("="*60 + "\n")
    
    # Verificar Python
    if not check_python_version():
        sys.exit(1)
    
    print("\n" + "-"*60)
    print("Verificando dependencias...")
    print("-"*60)
    
    # Lista de dependencias
    dependencies = [
        ("pymupdf", "PyMuPDF"),
        ("PIL", "Pillow"),
        ("numpy", "numpy"),
    ]
    
    missing = []
    
    for module, package in dependencies:
        if not check_import(module, package):
            missing.append(package)
    
    # Instalar dependencias faltantes
    if missing:
        print("\n" + "-"*60)
        print("Instalando dependencias faltantes...")
        print("-"*60)
        
        for package in missing:
            if not install_package(package):
                print(f"\n❌ Error al instalar {package}")
                print(f"   Intenta instalarlo manualmente: pip install {package}")
                sys.exit(1)
        
        print("\n" + "="*60)
        print("  ✓ Todas las dependencias instaladas correctamente")
        print("="*60)
    else:
        print("\n" + "="*60)
        print("  ✓ Todas las dependencias ya están instaladas")
        print("="*60)
    
    # Verificación final
    print("\nVerificación final...")
    all_ok = True
    
    try:
        import pymupdf
        print(f"✓ PyMuPDF {pymupdf.version[0]} importado correctamente")
    except Exception as e:
        print(f"❌ Error al importar PyMuPDF: {e}")
        all_ok = False
    
    try:
        from PIL import Image
        print(f"✓ Pillow importado correctamente")
    except Exception as e:
        print(f"❌ Error al importar Pillow: {e}")
        all_ok = False
    
    try:
        import numpy as np
        print(f"✓ NumPy {np.__version__} importado correctamente")
    except Exception as e:
        print(f"❌ Error al importar NumPy: {e}")
        all_ok = False
    
    print("\n" + "="*60)
    if all_ok:
        print("  ✓✓✓ Sistema listo para usar ✓✓✓")
        print("="*60)
        print("\nPróximos pasos:")
        print("  1. Crea archivos de ejemplo:")
        print("     python create_examples.py")
        print("\n  2. Aplica una máscara:")
        print("     python apply_mask_to_pdf.py sample.pdf mask_star.png output.pdf")
        print("\n  3. O usa la versión avanzada:")
        print("     python apply_mask_advanced.py sample.pdf mask_star.png output.pdf -g 30")
    else:
        print("  ❌ Hubo errores en la instalación")
        print("="*60)
        sys.exit(1)
    
    print("="*60 + "\n")


if __name__ == '__main__':
    main()
